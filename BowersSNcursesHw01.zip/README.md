Alcubierre
A roguelike programmed in C with the ncurses library.

For the final in CS 2060 - 003 (Spring 2018)

Works for macOS and Linux, haven't gotten Windows to work yet.

Compiled with cmake (to make compiling on different systems easier)
needs ncurses and panel libraries if not using cmake. On some linux systems may need ncursesw and panelw instead

make sure the file Alcubbiere_Title.xp in assets folder is next to the executable when running

Video of it working, since it's not working properly on all systems:
https://youtu.be/iFjF5uHtOC8
